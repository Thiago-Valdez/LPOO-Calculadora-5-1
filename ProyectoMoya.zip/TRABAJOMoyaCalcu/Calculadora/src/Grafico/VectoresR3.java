package Grafico;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class VectoresR3 extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldx1;
	private JTextField textFieldy1;
	private JTextField textFieldx2;
	private JTextField textFieldy2;
	private JTextField textFieldz1;
	private JTextField textFieldz2;
	private JTextField resultadoText;

	
	///
		//vector 1
		float x1,y1,z1;
		//vector 2
		float x2,y2,z2;
		
		int count=0;
		int variX=0;
		String numero = null;
		
		private JTextField multiText;
	///
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VectoresR3 frame = new VectoresR3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	private void insertarn(JButton boton) 
	{
		boton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent e)
			{
			
				if(variX==1) 
				{
					numero = multiText.getText() + boton.getText();
                    multiText.setText(numero);
					
				}else {
						switch(count) {
					
						case 0:
							numero=	textFieldx1.getText()+ boton.getText();
							textFieldx1.setText(numero);
							numero=null;
							count=1;
							break;
						case 1:
							numero=	textFieldy1.getText()+ boton.getText();
							textFieldy1.setText(numero);
							numero=null;
							count=2;
							break;
						case 2:
							numero=	textFieldz1.getText()+ boton.getText();
							textFieldz1.setText(numero);
							numero=null;
							count=3;
							break;
						case 3:
							numero=	textFieldx2.getText()+ boton.getText();
							textFieldx2.setText(numero);
							numero=null;
							count=4;
							break;
						case 4:
							numero=	textFieldy2.getText()+ boton.getText();
							textFieldy2.setText(numero);
							numero=null;
							count=5;
							break;
						case 5:
							numero=	textFieldz2.getText()+ boton.getText();
							textFieldz2.setText(numero);
							numero=null;
							count=6;
							break;
						case 6:
							count=0;
							break;
						}
				
				}
			
			}
			});
	}
	
	//llenar variables de x,y
	   private void parseVectorInputs() {
	        x1 = Float.parseFloat(textFieldx1.getText());
	        y1 = Float.parseFloat(textFieldy1.getText());
	        z1 = Float.parseFloat(textFieldz1.getText());
	        x2 = Float.parseFloat(textFieldx2.getText());
	        y2 = Float.parseFloat(textFieldy2.getText());
	        z2 = Float.parseFloat(textFieldz2.getText());
	   }
	   
	 //llenar variables para producto escalar
	   private void productollenar() {
	        x1 = Float.parseFloat(textFieldx1.getText());
	        y1 = Float.parseFloat(textFieldy1.getText());
	        z1 = Float.parseFloat(textFieldz1.getText());
	   }

	 //suma de vectores
	   private void sumvec() {
		   resultadoText.setText(null);
		   if(count==6) {
	        parseVectorInputs();
	        float sumX = x1 + x2;
	        float sumY = y1 + y2;
	        float sumZ = z1 + z2;
	        resultadoText.setText("(" + sumX + ", " + sumY + ", " + sumZ +")");
		   }	else 
		   		{
			   resultadoText.setText("Error, ingrese todos los valores");
		   		}
		   }
	   
	 //resta vectores
	   private void restavec() {
		   resultadoText.setText(null);
		   if(count==6) {
	        parseVectorInputs();
	        float resX = x1 - x2;
	        float resY = y1 - y2;
	        float resZ = z1 - z2;
	        resultadoText.setText("(" + resX + ", " + resY + ", " + resZ +")");
		   }	else 
		   		{
			   resultadoText.setText("Error, ingrese todos los valores");
		   		}
	    }
	   
	   
	   //multiplicacion por escalar
	   private void multiesc() {
		   productollenar();
	        float escalar = Float.parseFloat(multiText.getText());
	        float resX = x1 * escalar;
	        float resY = y1 * escalar;
	        float resZ = z1 * escalar;
	        resultadoText.setText("(" + resX + ", " + resY + ", " + resZ +")");
	    }
	   
	   
	   
	   
	   //producto vectorial
	   private void prodVec() {
		   resultadoText.setText(null);
		   if(count==6) {
	        parseVectorInputs();
	        float prodX= (y1 * z2) - (y2 * z1);
	        float prodY= (z1 * x1) - (z2 * x1);
	        float prodZ= (x1 * y2) - (x2 * y1);
	        resultadoText.setText("(" + prodX + ", " + prodY + ", " + prodZ +")");
		   }	else 
		   		{
			   resultadoText.setText("Error, ingrese todos los valores");
		   		}
	    }
	   
	   //producto escalar
	   private void prodESC() {
		   resultadoText.setText(null);
		   if(count==6) {
	        parseVectorInputs();
	        float dotProduct = x1 * x2 + y1 * y2 + z1 * z2;
	        resultadoText.setText(String.valueOf(dotProduct));
		   }	else 
		   		{
			   resultadoText.setText("Error, ingrese todos los valores");
		   		}
	    }
	/**
	 * Create the frame.
	 */
	public VectoresR3() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 538);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn7 = new JButton("7");
		btn7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn7.setForeground(Color.WHITE);
		btn7.setBackground(Color.LIGHT_GRAY);
		btn7.setBounds(40, 232, 70, 58);
		contentPane.add(btn7);
		insertarn(btn7);
		
		
		JButton btn8 = new JButton("8");
		btn8.setBackground(Color.LIGHT_GRAY);
		btn8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn8.setForeground(Color.WHITE);
		btn8.setBounds(144, 232, 70, 58);
		contentPane.add(btn8);
		insertarn(btn8);
		
		JButton btn9 = new JButton("9");
		btn9.setForeground(Color.WHITE);
		btn9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn9.setBackground(Color.LIGHT_GRAY);
		btn9.setBounds(244, 232, 70, 58);
		contentPane.add(btn9);
		insertarn(btn9);
		
		JButton btn4 = new JButton("4");
		btn4.setForeground(Color.WHITE);
		btn4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn4.setBackground(Color.LIGHT_GRAY);
		btn4.setBounds(40, 294, 70, 58);
		contentPane.add(btn4);
		insertarn(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.setForeground(Color.WHITE);
		btn5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn5.setBackground(Color.LIGHT_GRAY);
		btn5.setBounds(144, 294, 70, 58);
		contentPane.add(btn5);
		insertarn(btn5);
		
		
		JButton btn6 = new JButton("6");
		btn6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn6.setForeground(Color.WHITE);
		btn6.setBackground(Color.LIGHT_GRAY);
		btn6.setBounds(244, 294, 70, 58);
		contentPane.add(btn6);
		insertarn(btn6);
		
		JButton btn1 = new JButton("1");
		btn1.setForeground(Color.WHITE);
		btn1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn1.setBackground(Color.LIGHT_GRAY);
		btn1.setBounds(40, 363, 70, 58);
		contentPane.add(btn1);
		insertarn(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.setForeground(Color.WHITE);
		btn2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn2.setBackground(Color.LIGHT_GRAY);
		btn2.setBounds(144, 363, 70, 58);
		contentPane.add(btn2);
		insertarn(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.setForeground(Color.WHITE);
		btn3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn3.setBackground(Color.LIGHT_GRAY);
		btn3.setBounds(244, 363, 70, 58);
		contentPane.add(btn3);
		insertarn(btn3);
		
		JButton btn0 = new JButton("0");
		btn0.setForeground(Color.WHITE);
		btn0.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn0.setBackground(Color.LIGHT_GRAY);
		btn0.setBounds(144, 419, 70, 58);
		contentPane.add(btn0);
		insertarn(btn0);
		
		
		
		
		JLabel lblNewLabel = new JLabel("Vector 1");
		lblNewLabel.setForeground(Color.GREEN);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(10, 16, 124, 19);
		contentPane.add(lblNewLabel);
		
		JLabel lblVector = new JLabel("Vector 2");
		lblVector.setForeground(Color.GREEN);
		lblVector.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblVector.setBounds(10, 89, 100, 19);
		contentPane.add(lblVector);
		
		JLabel lblNewLabel_1 = new JLabel(",");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(159, 141, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel(",");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(159, 52, 46, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("(");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(48, 46, 46, 32);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("(");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_1.setBounds(48, 119, 46, 32);
		contentPane.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel(")");
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_1_1.setBounds(385, 130, 46, 32);
		contentPane.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_2_1_2 = new JLabel(")");
		lblNewLabel_2_1_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_1_2.setBounds(385, 41, 46, 32);
		contentPane.add(lblNewLabel_2_1_2);
		
		JLabel lblNewLabel_1_2 = new JLabel(",");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_2.setBounds(268, 141, 46, 14);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_1_1 = new JLabel(",");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_1_1.setBounds(268, 52, 46, 14);
		contentPane.add(lblNewLabel_1_1_1);
		
		JButton btnigual = new JButton("=");
		btnigual.setBackground(Color.LIGHT_GRAY);
		btnigual.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				multiesc();
			}
		});
		btnigual.setBounds(352, 119, 70, 36);
		contentPane.add(btnigual);
		btnigual.setVisible(false);
		
		JButton escalar = new JButton("X");
		escalar.setForeground(Color.WHITE);
		escalar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		escalar.setBackground(Color.GRAY);
		escalar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFieldx2.setVisible(false);
				textFieldy2.setVisible(false);
				textFieldz2.setVisible(false);
				lblVector.setVisible(false);
				lblNewLabel_2_1.setVisible(false);
				lblNewLabel_1_2.setVisible(false);
				lblNewLabel_1_2.setVisible(false);
				lblNewLabel_2_1_1.setVisible(false);
				lblNewLabel_1.setVisible(false);
				multiText.setVisible(true);
				btnigual.setVisible(true);
				variX=1;
			}
		});
		escalar.setBounds(352, 419, 70, 58);
		contentPane.add(escalar);
		
		
		JButton prodvec = new JButton("XVEC");
		prodvec.setFont(new Font("Tahoma", Font.PLAIN, 15));
		prodvec.setForeground(Color.WHITE);
		prodvec.setBackground(Color.GRAY);
		prodvec.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFieldx2.setVisible(true);
				textFieldy2.setVisible(true);
				textFieldz2.setVisible(true);
				lblVector.setVisible(true);
				lblNewLabel_2_1.setVisible(true);
				lblNewLabel_1_2.setVisible(true);
				lblNewLabel_1_2.setVisible(true);
				lblNewLabel_2_1_1.setVisible(true);
				lblNewLabel_1.setVisible(true);
				multiText.setVisible(false);
				btnigual.setVisible(false);
				multiText.setText(null);
				variX=0;
				prodVec();
			}
		});
		prodvec.setBounds(244, 419, 70, 58);
		contentPane.add(prodvec);
		
		
		
		JButton XESC = new JButton("XESC");
		XESC.setForeground(Color.WHITE);
		XESC.setFont(new Font("Tahoma", Font.PLAIN, 15));
		XESC.setBackground(Color.GRAY);
		XESC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFieldx2.setVisible(true);
				textFieldy2.setVisible(true);
				textFieldz2.setVisible(true);
				lblVector.setVisible(true);
				lblNewLabel_2_1.setVisible(true);
				lblNewLabel_1_2.setVisible(true);
				lblNewLabel_1_2.setVisible(true);
				lblNewLabel_2_1_1.setVisible(true);
				lblNewLabel_1.setVisible(true);
				multiText.setVisible(false);
				btnigual.setVisible(false);
				multiText.setText(null);
				variX=0;
				prodESC();
			}
		});
		XESC.setBounds(352, 232, 70, 58);
		contentPane.add(XESC);
		
	
		
		JButton mas = new JButton("+");
		mas.setForeground(Color.WHITE);
		mas.setFont(new Font("Tahoma", Font.PLAIN, 20));
		mas.setBackground(Color.GRAY);
		mas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFieldx2.setVisible(true);
				textFieldy2.setVisible(true);
				textFieldz2.setVisible(true);
				lblVector.setVisible(true);
				lblNewLabel_2_1.setVisible(true);
				lblNewLabel_1_2.setVisible(true);
				lblNewLabel_1_2.setVisible(true);
				lblNewLabel_2_1_1.setVisible(true);
				lblNewLabel_1.setVisible(true);
				multiText.setVisible(false);
				btnigual.setVisible(false);
				multiText.setText(null);
				variX=0;
				sumvec();
			}
		});
		mas.setBounds(352, 294, 70, 58);
		contentPane.add(mas);
		
		
		
		JButton menos = new JButton("-");
		menos.setForeground(Color.WHITE);
		menos.setFont(new Font("Tahoma", Font.PLAIN, 20));
		menos.setBackground(Color.GRAY);
		menos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFieldx2.setVisible(true);
				textFieldy2.setVisible(true);
				textFieldz2.setVisible(true);
				lblVector.setVisible(true);
				lblNewLabel_2_1.setVisible(true);
				lblNewLabel_1_2.setVisible(true);
				lblNewLabel_1_2.setVisible(true);
				lblNewLabel_2_1_1.setVisible(true);
				lblNewLabel_1.setVisible(true);
				multiText.setVisible(false);
				btnigual.setVisible(false);
				multiText.setText(null);
				variX=0;
				restavec();
			}
		});
		menos.setBounds(352, 357, 70, 58);
		contentPane.add(menos);
		
		
		textFieldx1 = new JTextField();
		textFieldx1.setFont(new Font("Arial", Font.PLAIN, 15));
		textFieldx1.setColumns(10);
		textFieldx1.setBounds(79, 36, 70, 48);
		contentPane.add(textFieldx1);
		
		textFieldy1 = new JTextField();
		textFieldy1.setFont(new Font("Arial", Font.PLAIN, 15));
		textFieldy1.setColumns(10);
		textFieldy1.setBounds(188, 36, 70, 48);
		contentPane.add(textFieldy1);
		
		textFieldx2 = new JTextField();
		textFieldx2.setFont(new Font("Arial", Font.PLAIN, 15));
		textFieldx2.setColumns(10);
		textFieldx2.setBounds(79, 114, 70, 48);
		contentPane.add(textFieldx2);
		
		textFieldy2 = new JTextField();
		textFieldy2.setFont(new Font("Arial", Font.PLAIN, 15));
		textFieldy2.setColumns(10);
		textFieldy2.setBounds(188, 114, 70, 48);
		contentPane.add(textFieldy2);
		
		
		textFieldz1 = new JTextField();
		textFieldz1.setFont(new Font("Arial", Font.PLAIN, 15));
		textFieldz1.setColumns(10);
		textFieldz1.setBounds(305, 36, 70, 48);
		contentPane.add(textFieldz1);
		
		textFieldz2 = new JTextField();
		textFieldz2.setFont(new Font("Arial", Font.PLAIN, 15));
		textFieldz2.setColumns(10);
		textFieldz2.setBounds(305, 114, 70, 48);
		contentPane.add(textFieldz2);
		
		resultadoText = new JTextField();
		resultadoText.setBounds(120, 171, 208, 50);
		contentPane.add(resultadoText);
		resultadoText.setColumns(10);
		
		JButton btnC = new JButton("C");
		btnC.setBackground(Color.LIGHT_GRAY);
		btnC.setForeground(Color.RED);
		btnC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resultadoText.setText(null);
				textFieldx1.setText(null);
				textFieldy1.setText(null);
				textFieldx2.setText(null);
				textFieldy2.setText(null);
				textFieldz1.setText(null);
				textFieldz2.setText(null);
				multiText.setText(null);
				textFieldx2.setVisible(true);
				textFieldy2.setVisible(true);
				textFieldz2.setVisible(true);
				lblVector.setVisible(true);
				lblNewLabel_2_1.setVisible(true);
				lblNewLabel_1_2.setVisible(true);
				lblNewLabel_1_2.setVisible(true);
				lblNewLabel_2_1_1.setVisible(true);
				lblNewLabel_1.setVisible(true);
				multiText.setVisible(false);
				btnigual.setVisible(false);
				variX=0;
				count=0;
			}
		});
		btnC.setBounds(352, 183, 70, 38);
		contentPane.add(btnC);
		

	
		
		multiText = new JTextField();
		multiText.setBounds(144, 117, 158, 38);
		contentPane.add(multiText);
		multiText.setColumns(10);
		
		JButton volver = new JButton("HOME");
		volver.setBackground(Color.LIGHT_GRAY);
		volver.setFont(new Font("Tahoma", Font.PLAIN, 15));
		volver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		volver.setBounds(28, 445, 82, 32);
		contentPane.add(volver);
		multiText.setVisible(false);
		
		
	}
}
