package Grafico;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class Matrices extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JButton btnNewButton_4;
	private JButton btnNewButton_5;
	private JButton btnNewButton_6;
	private JButton btnNewButton_7;
	private JButton btnNewButton_8;
	private JTextField[][] MatrizA;
    private JTextField[][] MatrizB;
    private JButton btnNewButton_11;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Matrices frame = new Matrices();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private void crearMatrices2x2() {
		 MatrizA = new JTextField[2][2];
	        for (int i = 0; i < 2; i++) {
	            for (int j = 0; j < 2; j++) {
	                MatrizA[i][j] = new JTextField();
	                MatrizA[i][j].setBounds(60 + j * 90, 100 + i * 100, 80, 80);
	                contentPane.add(MatrizA[i][j]);
	            }
	        }

	      MatrizB = new JTextField[2][2];
	        for (int i = 0; i < 2; i++) {
	            for (int j = 0; j < 2; j++) {
	                MatrizB[i][j] = new JTextField();
	                MatrizB[i][j].setBounds(500 + j * 90, 100 + i * 100, 80, 80);
	                contentPane.add(MatrizB[i][j]);
	            }
	        }
	        contentPane.revalidate();
	        contentPane.repaint();
		}

	private void crearMatrices3x3() {
		 MatrizA = new JTextField[3][3];
	        for (int i = 0; i < 3; i++) {
	            for (int j = 0; j < 3; j++) {
	                MatrizA[i][j] = new JTextField();
	                MatrizA[i][j].setBounds(20 + j * 90, 50 + i * 100, 70, 70);
	                contentPane.add(MatrizA[i][j]);
	            }
	        }

	      MatrizB = new JTextField[3][3];
	        for (int i = 0; i < 3; i++) {
	            for (int j = 0; j < 3; j++) {
	                MatrizB[i][j] = new JTextField();
	                MatrizB[i][j].setBounds(450 + j * 90, 50 + i * 100, 70, 70);
	                contentPane.add(MatrizB[i][j]);
	            }
	        }
	        contentPane.revalidate();
	        contentPane.repaint();
		}
	/**
	 * Create the frame.
	 */
	public Matrices() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 759, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Matrices");
		lblNewLabel.setBounds(326, 11, 74, 25);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("+");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(293, 79, 145, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("-");
		btnNewButton_1.setBounds(293, 124, 145, 23);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("x");
		btnNewButton_2.setBounds(293, 170, 145, 23);
		contentPane.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("/");
		btnNewButton_3.setBounds(293, 215, 145, 23);
		contentPane.add(btnNewButton_3);
		
		btnNewButton_4 = new JButton("Determinante");
		btnNewButton_4.setBounds(23, 323, 128, 23);
		contentPane.add(btnNewButton_4);
		
		btnNewButton_5 = new JButton("Inversa");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_5.setBounds(155, 323, 128, 23);
		contentPane.add(btnNewButton_5);
		
		btnNewButton_6 = new JButton("X escalares");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_6.setBounds(293, 261, 145, 23);
		contentPane.add(btnNewButton_6);
		
		btnNewButton_7 = new JButton("Determinante");
		btnNewButton_7.setBounds(448, 323, 128, 23);
		contentPane.add(btnNewButton_7);
		
		btnNewButton_8 = new JButton("Inversa");
		btnNewButton_8.setBounds(580, 323, 128, 23);
		contentPane.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("Menu");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton_9.setBounds(23, 16, 89, 23);
		contentPane.add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("2x2");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crearMatrices2x2();
			}
		});
		btnNewButton_10.setBounds(326, 357, 89, 23);
		contentPane.add(btnNewButton_10);
		
		btnNewButton_11 = new JButton("3x3");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crearMatrices3x3();
			}
		});
		btnNewButton_11.setBounds(326, 391, 89, 23);
		contentPane.add(btnNewButton_11);
	}
}
